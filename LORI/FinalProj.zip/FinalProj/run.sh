html2jade html/home.htm 
mv html/home.jade views/
nodemon bin/www
